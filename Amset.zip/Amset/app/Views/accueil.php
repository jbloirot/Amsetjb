<?= $this->extend('_layout') ?>

<?= $this->section('contenu') ?>




<!--  -->

<div class="heroe">

    <h1>Bienvenue sur la page D'accueil</h1>

    <h2>Page D'accueil </h2>




    </header>
    <!-- commencer le code ici  -->

</div>

</header>





<?= $this->endSection() ?>