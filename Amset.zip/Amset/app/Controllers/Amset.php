<?php

namespace App\Controllers;

class Amset extends BaseController
{

    public function main(): string
    {
        return view('accueil');
    }
}
